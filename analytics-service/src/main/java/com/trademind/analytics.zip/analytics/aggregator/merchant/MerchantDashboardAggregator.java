package com.trademind.analytics.aggregator.merchant;

import com.trademind.analytics.client.billing.BillingClient;
import com.trademind.analytics.client.inventory.InventoryClient;
import com.trademind.analytics.client.order.OrderClient;
import com.trademind.analytics.client.order.dto.OrderCountResponse;
import com.trademind.analytics.client.order.dto.OrderSummaryResponse;
import com.trademind.analytics.client.product.ProductClient;
import com.trademind.analytics.dto.common.*;
import com.trademind.analytics.dto.merchant.MerchantDashboardResponse;
import com.trademind.analytics.mapper.OrderMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

@Component
@RequiredArgsConstructor
public class MerchantDashboardAggregator {

    private final ProductClient productClient;
    private final OrderClient orderClient;
    private final BillingClient billingClient;
    private final InventoryClient inventoryClient;
    private final Executor analyticsExecutor;


    public MerchantDashboardResponse getDashboard(Long merchantId) {

        CompletableFuture<Long> productsFuture =
                CompletableFuture.supplyAsync(() ->
                        productClient.getProductsByMerchant(merchantId), analyticsExecutor
                );

        CompletableFuture<OrderCountResponse> ordersFuture =
                CompletableFuture.supplyAsync(() ->
                        orderClient.getOrdersByMerchant(merchantId), analyticsExecutor
                );

        CompletableFuture<String> revenueFuture =
                CompletableFuture.supplyAsync(() ->
                        billingClient.getRevenueByMerchant(merchantId), analyticsExecutor
                );

        CompletableFuture<List<com.trademind.analytics.client.inventory.dto.LowStockResponse>> stockFuture =
                CompletableFuture.supplyAsync(() ->
                        inventoryClient.getLowStockProducts(merchantId), analyticsExecutor
                );

        CompletableFuture<List<OrderSummaryResponse>> recentOrdersFuture =
                CompletableFuture.supplyAsync(() ->
                        orderClient.getRecentOrders(merchantId), analyticsExecutor);

        CompletableFuture.allOf(productsFuture, ordersFuture, revenueFuture, stockFuture,recentOrdersFuture).join();

        List<MetricCardDto> metrics = List.of(
                MetricCardDto.builder().title("Total Products").value(String.valueOf(productsFuture.join())).build(),
                MetricCardDto.builder().title("Orders").value(String.valueOf(ordersFuture.join())).build(),
                MetricCardDto.builder().title("Revenue").value(revenueFuture.join()).build()
        );

        List<LowStockDto> lowStock = stockFuture.join().stream()
                .map(s -> LowStockDto.builder()
                        .productName(s.getProductName())
                        .sku(s.getSku())
                        .remaining(s.getRemaining())
                        .minRequired(s.getMinRequired())
                        .build())
                .toList();

        List<OrderSummaryDto> recentOrders =
                OrderMapper.map(recentOrdersFuture.join());

        return MerchantDashboardResponse.builder()
                .metrics(metrics)
                .recentOrders(recentOrders) // next
                .lowStockAlerts(lowStock)
                .build();
    }
}