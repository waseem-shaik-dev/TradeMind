package com.trademind.analytics.client.billing;

import com.trademind.analytics.client.billing.dto.RevenueRequestDto;
import com.trademind.analytics.client.billing.dto.RevenueResponseDto;
import com.trademind.analytics.client.billing.dto.TopMerchantRawDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(
        name = "billing-service",
        url = "http://localhost:8085",
        configuration = com.trademind.analytics.client.config.FeignConfig.class
)
public interface BillingClient {

    @GetMapping("/api/billing/total-revenue")
    String getTotalRevenue();

    @GetMapping("/api/billing/revenue/by-merchant")
    String getRevenueByMerchant(@RequestParam Long merchantId);

    @GetMapping("/api/billing/revenue/by-retailer")
    String getRevenueByRetailer(@RequestParam Long retailerId);

    @GetMapping("/api/billing/today-sales")
    String getTodaySales(@RequestParam Long retailerId);

    @GetMapping("/api/billing/revenue/by-customer")
    String getRevenueByCustomer(@RequestParam Long customerId);

    @GetMapping("/api/billing/top-merchants")
    List<TopMerchantRawDto> getTopMerchants(@RequestParam int limit);

    @PostMapping("/api/billing/revenue")
    RevenueResponseDto getRevenue(RevenueRequestDto request);}