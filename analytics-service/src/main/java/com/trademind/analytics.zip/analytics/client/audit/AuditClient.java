package com.trademind.analytics.client.audit;

import com.trademind.analytics.dto.common.RecentActivityDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(name = "audit-service", url = "http://localhost:8089")
public interface AuditClient {

    @GetMapping("/api/audit-logs/recent")
    List<RecentActivityDto> getRecentActivities(
            @RequestParam(defaultValue = "10") int limit);
}