package com.trademind.analytics.aggregator.admin;

import com.trademind.analytics.client.audit.AuditClient;
import com.trademind.analytics.client.billing.BillingClient;
import com.trademind.analytics.client.order.OrderClient;
import com.trademind.analytics.client.order.dto.OrderCountResponse;
import com.trademind.analytics.client.user.UserClient;
import com.trademind.analytics.dto.admin.AdminDashboardResponse;
import com.trademind.analytics.dto.common.*;
import com.trademind.analytics.mapper.TopPerformerMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

@Component
@RequiredArgsConstructor
public class AdminDashboardAggregator {

    private final UserClient userClient;
    private final OrderClient orderClient;
    private final BillingClient billingClient;
    private final Executor analyticsExecutor;
    private final AuditClient auditClient;

    public AdminDashboardResponse getDashboard() {

        CompletableFuture<?> usersFuture = CompletableFuture.supplyAsync(
                userClient::getUserCounts, analyticsExecutor
        );

        CompletableFuture<OrderCountResponse> ordersFuture = CompletableFuture.supplyAsync(
                orderClient::getTotalOrders, analyticsExecutor
        );

        CompletableFuture<String> revenueFuture = CompletableFuture.supplyAsync(
                billingClient::getTotalRevenue, analyticsExecutor
        );

        CompletableFuture<List<RecentActivityDto>> activityFuture =
                CompletableFuture.supplyAsync(() ->
                                auditClient.getRecentActivities(10),
                        analyticsExecutor
                );

        CompletableFuture<List<TopPerformerDto>> topMerchantsFuture =
                CompletableFuture.supplyAsync(() ->
                                TopPerformerMapper.map(
                                        billingClient.getTopMerchants(5)
                                ),
                        analyticsExecutor
                );

        CompletableFuture.allOf(usersFuture, ordersFuture, revenueFuture,activityFuture,topMerchantsFuture).join();

        var users = (com.trademind.analytics.client.user.dto.UserCountResponse) usersFuture.join();
        OrderCountResponse totalOrders = ordersFuture.join();
        String revenue = revenueFuture.join();
        List<RecentActivityDto> activities =
                activityFuture.exceptionally(ex -> List.of()).join();
        List<TopPerformerDto> topMerchants = topMerchantsFuture.exceptionally(ex->List.of()).join();

        List<MetricCardDto> metrics = List.of(
                MetricCardDto.builder()
                        .title("Total Merchants")
                        .value(String.valueOf(users.getTotalMerchants()))
                        .change("+12%")
                        .positive(true)
                        .build(),

                MetricCardDto.builder()
                        .title("Total Retailers")
                        .value(String.valueOf(users.getTotalRetailers()))
                        .change("+8%")
                        .positive(true)
                        .build(),

                MetricCardDto.builder()
                        .title("Total Customers")
                        .value(String.valueOf(users.getTotalCustomers()))
                        .change("+15%")
                        .positive(true)
                        .build(),

                MetricCardDto.builder()
                        .title("Total Revenue")
                        .value(revenue)
                        .change("+22%")
                        .positive(true)
                        .build()
        );

        return AdminDashboardResponse.builder()
                .metrics(metrics)
                .recentActivities(activities) // fill later (notification/audit)
                .topMerchants(topMerchants)     // fill later
                .build();
    }
}