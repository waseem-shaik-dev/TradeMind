package com.trademind.analytics.aggregator.retailer;

import com.trademind.analytics.client.billing.BillingClient;
import com.trademind.analytics.client.inventory.InventoryClient;
import com.trademind.analytics.client.order.OrderClient;
import com.trademind.analytics.client.order.dto.OrderSummaryResponse;
import com.trademind.analytics.client.product.ProductClient;
import com.trademind.analytics.dto.common.*;
import com.trademind.analytics.dto.retailer.*;
import com.trademind.analytics.mapper.OrderMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

@Component
@RequiredArgsConstructor
public class RetailerDashboardAggregator {

    private final ProductClient productClient;
    private final OrderClient orderClient;
    private final BillingClient billingClient;
    private final InventoryClient inventoryClient;
    private final Executor analyticsExecutor;


    public RetailerDashboardResponse getDashboard(Long retailerId) {

        CompletableFuture<Long> products =
                CompletableFuture.supplyAsync(() ->
                        productClient.getProductsByRetailer(retailerId), analyticsExecutor);

        CompletableFuture<Long> orders =
                CompletableFuture.supplyAsync(() ->
                        orderClient.getOrdersByRetailer(retailerId), analyticsExecutor);

        CompletableFuture<String> todaySales =
                CompletableFuture.supplyAsync(() ->
                        billingClient.getTodaySales(retailerId), analyticsExecutor);

        CompletableFuture<Integer> lowStock =
                CompletableFuture.supplyAsync(() ->
                        inventoryClient.getLowStockCount(retailerId), analyticsExecutor);

        CompletableFuture<List<OrderSummaryResponse>> salesFuture =
                CompletableFuture.supplyAsync(() ->
                        orderClient.getRecentOrders(retailerId), analyticsExecutor);

        CompletableFuture.allOf(products, orders, todaySales, lowStock,salesFuture).join();

        List<MetricCardDto> metrics = List.of(
                MetricCardDto.builder().title("Products").value(String.valueOf(products.join())).build(),
                MetricCardDto.builder().title("Orders").value(String.valueOf(orders.join())).build(),
                MetricCardDto.builder().title("Today's Sales").value(todaySales.join()).build()
        );

        QuickStatsDto stats = QuickStatsDto.builder()
                .weeklySales("$12,450")
                .monthlySales("$48,200")
                .customers(256)
                .lowStockItems(lowStock.join())
                .build();

        List<OrderSummaryDto> recentSales = OrderMapper.map(salesFuture.join());

        return RetailerDashboardResponse.builder()
                .metrics(metrics)
                .recentSales(recentSales)
                .quickStats(stats)
                .build();
    }
}