package com.trademind.analytics.aggregator.customer;

import com.trademind.analytics.client.billing.BillingClient;
import com.trademind.analytics.client.order.OrderClient;
import com.trademind.analytics.client.order.dto.OrderCountResponse;
import com.trademind.analytics.client.order.dto.OrderSummaryResponse;
import com.trademind.analytics.dto.common.*;
import com.trademind.analytics.dto.customer.CustomerDashboardResponse;
import com.trademind.analytics.mapper.OrderMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

@Component
@RequiredArgsConstructor
public class CustomerDashboardAggregator {

    private final OrderClient orderClient;
    private final BillingClient billingClient;
    private final Executor analyticsExecutor;


    public CustomerDashboardResponse getDashboard(Long customerId) {

        CompletableFuture<OrderCountResponse> totalOrders =
                CompletableFuture.supplyAsync(() ->
                        orderClient.getOrdersByCustomer(customerId), analyticsExecutor
                );

        CompletableFuture<Long> activeOrders =
                CompletableFuture.supplyAsync(() ->
                        orderClient.getActiveOrders(customerId), analyticsExecutor);

        CompletableFuture<String> totalSpent =
                CompletableFuture.supplyAsync(() ->
                        billingClient.getRevenueByCustomer(customerId), analyticsExecutor
                );

        CompletableFuture<List<OrderSummaryResponse>> ordersFuture =
                CompletableFuture.supplyAsync(() ->
                        orderClient.getRecentOrders(customerId), analyticsExecutor);

        CompletableFuture.allOf(totalOrders, activeOrders, totalSpent,ordersFuture).join();

        List<MetricCardDto> metrics = List.of(
                MetricCardDto.builder().title("Total Orders").value(String.valueOf(totalOrders.join())).build(),
                MetricCardDto.builder().title("Active Orders").value(String.valueOf(activeOrders.join())).build(),
                MetricCardDto.builder().title("Total Spent").value(totalSpent.join()).build()
        );

        List<OrderSummaryDto> recentOrders = OrderMapper.map(ordersFuture.join());

        return CustomerDashboardResponse.builder()
                .metrics(metrics)
                .recentOrders(recentOrders)
                .build();
    }
}